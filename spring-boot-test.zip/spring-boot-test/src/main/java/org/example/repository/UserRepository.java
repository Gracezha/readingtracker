package org.example.repository;

import org.example.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

// Repository for the user table
@Repository
public interface UserRepository extends JpaRepository<User, String> {
    User findByUsername(String username); // Find user by username
    User findByUsernameAndPwd(String username, String pwd);
}
