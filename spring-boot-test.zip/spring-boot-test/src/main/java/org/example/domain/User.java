package org.example.domain;

import jakarta.persistence.*;

@Table(name="user")
@Entity
public class User {
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    @Id
    private String username; // Maps to username column
    private String pwd;      // Maps to pwd column
    private String trole;    // Maps to trole column

    // Getters and setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getTrole() {
        return trole;
    }

    public void setTrole(String trole) {
        this.trole = trole;
    }
}
