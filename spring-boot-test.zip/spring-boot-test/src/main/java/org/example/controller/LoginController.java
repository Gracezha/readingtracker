package org.example.controller;

import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletResponse;
import org.example.domain.User;
import org.example.repository.UserRepository;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@CrossOrigin(origins = "*")
public class LoginController {
    @Resource
    private UserRepository userRepository;

    @GetMapping("/login")
    @CrossOrigin(origins = "*")
    public String login(HttpServletResponse response, @RequestParam("username") String username, @RequestParam("pwd") String password) {
        response.addHeader("Access-Control-Allow-Origin", "*");
        User user = userRepository.findByUsername(username);
        if (user != null && password.equals(user.getPwd())) {
            if ("y".equals(user.getTrole())){
                return "teacher";
            }
            return "student";
        }
        return "登陆失败";
    }
//    public String login(String username, String password) {
//        User user = userRepository.findByUsername(username);
//        if (user != null && user.getPwd().equals(password)) {
//            return user.getTrole();
//        }
//        return "登陆失败";
//    }

    @GetMapping("/dashboard")
    public String dashboard(Authentication authentication, Model model) {
        String username = authentication.getName();
        if (authentication.getAuthorities().contains(new SimpleGrantedAuthority("ROLE_TEACHER"))) {
            model.addAttribute("message", "Welcome, " + username + "!");
            return "templates/teacher.html";
        } else if (authentication.getAuthorities().contains(new SimpleGrantedAuthority("ROLE_STUDENT"))) {
            model.addAttribute("message", "Welcome, " + username + "!");
            return "templates/student.html";
        }
        return "redirect:/login";
    }
}
