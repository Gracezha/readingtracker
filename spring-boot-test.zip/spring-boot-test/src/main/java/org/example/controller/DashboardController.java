package org.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@CrossOrigin(origins = "*")
public class DashboardController {
    @GetMapping("/goal-tracker.html")
    public String goalTracker(){
        return "goal-tracker";
    }

    @GetMapping("/reading-journal.html")
    public String readingJournal(){
        return "reading-journal";
    }

}
